#Slightly more complicated with more visual output and run time comparison located here: https://github.com/Sambardo/PowerShell_Runspaces_Examples/blob/main/RunspacePools_Timers.ps1

#Simple runspace pool with 5 max threads and random run times
$RunspacePool = [runspacefactory]::CreateRunspacePool(1,5)
$RunspacePool.Open()

[System.Collections.ArrayList]$RunspaceList = @()

Foreach($Instance in 1..10) {
    $PowerShell = [powershell]::Create()
    $PowerShell.RunspacePool = $RunspacePool
    
    [void]$PowerShell.AddScript({
param ($InstanceNumber)
        $timeToSleep = get-random -Minimum 10 -Maximum 60
    Start-Sleep -Seconds $timeToSleep
        "Runspace $InstanceNumber took $timeToSleep seconds!"
    })
    [void]$PowerShell.AddParameter("InstanceNumber",$Instance)
    
    $RunspaceList.Add([pscustomobject]@{
        InstanceNumber = $Instance
        PowerShell       = $PowerShell
        AsyncResult      = $PowerShell.BeginInvoke()
    })
}

foreach($Instance in $RunspaceList)
{
    $Instance.PowerShell.Endinvoke($Instance.AsyncResult)
    $Instance.PowerShell.Dispose()
}
$RunspacePool.dispose() 
