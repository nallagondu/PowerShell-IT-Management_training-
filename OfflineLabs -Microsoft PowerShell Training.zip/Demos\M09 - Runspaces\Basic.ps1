$Powershell = [PowerShell]::Create()
$Powershell.Runspace.RunspaceStateInfo
$PowerShell.AddScript({Start-Sleep -Seconds 5;'Done'})
$PowerShell.Invoke()
$PowerShell.Dispose()
