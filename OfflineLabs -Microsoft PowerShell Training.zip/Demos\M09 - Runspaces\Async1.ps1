$Powershell = [PowerShell]::Create() 
$PowerShell.AddScript({Start-Sleep -Seconds 20;'Done'})
$Async = $PowerShell.BeginInvoke() 
 
$Async
 
$PowerShell.EndInvoke($Async)
