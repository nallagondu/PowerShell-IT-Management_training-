Function Foo{
    param($foo)
    Bar -bar ($foo+1)
}
Function Bar{
    param($bar)
    Wam -wam ($bar+1)
}
Function Wam{
    param($wam)
    Bam -bam ($wam+1)
}
Function Bam{
    param($bam)
    Write-Host ($bam+1)
    Get-PSCallStack
}

Foo -foo 5