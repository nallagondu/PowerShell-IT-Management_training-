﻿$ServiceNames = "ALG","AudioSrv","WinDefend","p2pimsvc"
$ServiceNames += "WSearch"

Function ServiceStuff
{
    param($service)
    if($service.status -eq "running"){
        Write-Host $Service.displayName -ForegroundColor Green
    }
    else {
        Write-Host $Service.displayName -ForegroundColor Yellow
    }
    Write-DependentServices $service
}

Function Write-DependentServices{
    param ($Service)
    foreach($s in $Service.DependentServices){
        Write-Host "`t $($s.displayName)" -ForegroundColor Cyan
    }
}

foreach ($serviceName in $serviceNames)
{
    $Service = get-service $serviceName
    ServiceStuff -service $service
}

Write-Host "end of script" -ForegroundColor Green