#None of these error by default
$Var
$Var  = 0..5
$Var.FakeProperty
$Var[100]


#strict mode will generate terminating errors now
Set-StrictMode -Version latest

$Var[100]
$Var.FakeProperty
$DoesNotExist
