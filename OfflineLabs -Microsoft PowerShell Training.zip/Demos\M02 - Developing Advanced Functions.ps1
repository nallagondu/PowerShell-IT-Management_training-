﻿
#region Parameter Basics
Function Test-Params
{
    param($p1,
          $p2 = "default",
          [string]$p3 = 5)
    Write-host "p1: $p1, P2: $p2, P3: $p3"
}

Test-Params -p1 1 -p2 2 -p3 3
Test-Params 1 2 3
Test-Params

#endregion


#region CmdeltBinding

Function Test-Function
{
    param($p1, $p2)
    Write-host "p1 is $p1" -ForegroundColor Yellow
    Write-host "p2 is $p2" -ForegroundColor Yellow
}
#show intellisense

Function Test-Function
{
    [cmdletbinding()]
    param($p1, $p2)
    Write-host "p1 is $p1" -ForegroundColor Yellow
    Write-host "p2 is $p2" -ForegroundColor Yellow
}
#show intellisense
#endregion


#region Using common params
#nothing special, because we didn't use it.
Test-Function -p1 a -p2 b -Verbose

Function Test-Function
{
    [cmdletbinding()]
    param($p1, $p2)
    Write-host "p1 is $p1" -ForegroundColor Yellow
    Write-host "p2 is $p2" -ForegroundColor Yellow
    Write-verbose "super secret verbose logging info"
}
Test-Function -p1 a -p2 b -Verbose

#endregion

#region Risk mitigation
#fake example
Function Test-Risk
{
    [cmdletbinding(SupportsShouldProcess)]
    param($processName)
    $proc = Get-Process -name $processName
    $id = $proc.Id
    write-host "I'm killing $processName($id)" -ForegroundColor Red
}
#open notepad
Test-Risk "notepad"
Test-Risk "notepad" -WhatIf  #doesn't do anythign yet
Test-Risk "notepad" -confirm #doesn't do anythign yet

Function Test-Risk
{
    [cmdletbinding(SupportsShouldProcess)]
    param($processName)
    #we still need the ID, so we always want to run this code
    $proc = Get-Process -name $processName
    $id = $proc.Id

    #we need to check IF we should run the "action" code
    if($PSCmdlet.ShouldProcess("$processName($id)", "Stopping process"))
    {
        write-host "I'm killing $processName($id)" -ForegroundColor Red
    }
}

Test-Risk "notepad"
Test-Risk "outlook" -WhatIf
Test-Risk "notepad" -confirm  #can click yes or no and see it work

$ConfirmPreference
Function Test-Risk
{
    [cmdletbinding(SupportsShouldProcess,
                   ConfirmImpact="high")]
    param($processName)
    #we still need the ID, so we always want to run this code
    $proc = Get-Process -name $processName
    $id = $proc.Id

    #we need to check IF we should run the "action" code
    if($PSCmdlet.ShouldProcess("$processName($id)", "Stopping process"))
    {
        write-host "I'm killing $processName($id)" -ForegroundColor Red
    }
}
Test-Risk "notepad"
Test-Risk "notepad" -confirm:$false


#endregion

