#region Load GUI
Add-Type -AssemblyName presentationframework, presentationcore
$XAML= [XML](Get-Content -Path "$PSScriptRoot\Demo-DirectoryExplorer\MainWindow.xaml" -Raw)
$XAML.Window.RemoveAttribute('x:Class')
$XAML.Window.RemoveAttribute('xmlns:local')
$XAML.Window.RemoveAttribute('xmlns:d')
$XAML.Window.RemoveAttribute('xmlns:mc')
$XAML.Window.RemoveAttribute('mc:Ignorable')

#read XML as XAML
$XAMLreader = New-Object System.Xml.XmlNodeReader $XAML
$Rawform = [Windows.Markup.XamlReader]::Load($XAMLreader) 

#add XML namespace manager
$XmlNamespaceManager = [System.Xml.XmlNamespaceManager]::New($XAML.NameTable)
$XmlNamespaceManager.AddNamespace('x','http://schemas.microsoft.com/winfx/2006/xaml')

#Create hash table containing a representation of all controls
$GUI = @{}
$namedNodes = $XAML.SelectNodes("//*[@x:Name]",$XmlNamespaceManager)
$namedNodes | ForEach-Object -Process {$GUI.Add($_.Name, $Rawform.FindName($_.Name))}

#endregion

<#Create button code
-Empty out existing items from the list box
-Check if the typed path existis (insert "invalid path" and end if it is not real)
-Check if the file button is checked off, and fetch file names for $data
-Otherwise the directory one must be checked, so get directory names for $data
-Add $data items to listbox
#>
$ButtonSB = {
    $GUI["DisplayListBox"].Items.Clear()
    if(!(Test-Path $GUI["PathTextBox"].text))
    {
        $GUI["DisplayListBox"].Items.Add("INVALID PATH")
        return
    }

    if($GUI["FileRadioButton"].isChecked){$data = Get-ChildItem -Path $GUI["PathTextBox"].text -file}
    else{$data = Get-ChildItem -Path $GUI["PathTextBox"].text -Directory}

    foreach ($name in $data)
    {
        $GUI["DisplayListBox"].Items.add($name.Name)
    }
}

$GUI["SearchButton"].Add_Click($ButtonSB)

$Rawform.ShowDialog() | Out-Null