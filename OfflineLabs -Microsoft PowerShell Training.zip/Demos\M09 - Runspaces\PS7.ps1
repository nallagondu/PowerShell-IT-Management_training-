#ThreadJob
$TJ = Start-ThreadJob -ScriptBlock {
    Start-sleep 10
    "End" 
    }
Write-Host "Do Stuff"
Wait-Job $TJ | out-null
Receive-Job $TJ 

#Foreach
$StartTime = get-date
1..10 | ForEach-Object -Parallel {
    "Output: $_"
    Start-Sleep 1
}
((get-date) - $StartTime).Seconds 
