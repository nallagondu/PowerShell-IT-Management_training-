﻿#Add WPF assemblies
Add-Type -AssemblyName PresentationCore,PresentationFramework

#Cleanup XAML options
$XAML= [XML](Get-Content -Path "$PSScriptRoot\UserNameGenerator\MainWindow.xaml" -Raw)
#$XAML= [XML](Get-Content -Path "c:\PS1\GUI\WpfApp3\WpfApp3\MainWindow.xaml" -Raw)
$XAML.Window.RemoveAttribute('x:Class')
$XAML.Window.RemoveAttribute('xmlns:local')
$XAML.Window.RemoveAttribute('xmlns:d')
$XAML.Window.RemoveAttribute('xmlns:mc')
$XAML.Window.RemoveAttribute('mc:Ignorable')

#read XML as XAML
$XAMLreader = New-Object System.Xml.XmlNodeReader $XAML
$Rawform = [Windows.Markup.XamlReader]::Load($XAMLreader)

#add XML namespace manager
$XmlNamespaceManager = [System.Xml.XmlNamespaceManager]::New($XAML.NameTable)
$XmlNamespaceManager.AddNamespace('x','http://schemas.microsoft.com/winfx/2006/xaml')

#Create hash table containing a representation of all controls
$GUI = @{}
$namedNodes = $XAML.SelectNodes("//*[@x:Name]",$XmlNamespaceManager)
$namedNodes | ForEach-Object -Process {$GUI.Add($_.Name, $Rawform.FindName($_.Name))}

#PowerShell code for button actions


$ButtonClick = {
    $FirstName = $GUI["txtFirstName"].Text
    $LastName = $GUI["txtLastName"].Text

    if ($GUI["btnStandard"].IsChecked) {
        $UserName = $FirstName.Substring(0,1) + $LastName
    }
    elseif ($GUI["btnAdmin"].IsChecked) {
        $UserName = $FirstName.Substring(0,1) + $LastName + "-adm"
    }
    elseif ($GUI["btnGuest"].IsChecked) {
        $UserName = $FirstName.Substring(0,1) + $LastName+ "-guest"
    }
    elseif ($GUI["btnPartner"].IsChecked) {
        $UserName = $FirstName.Substring(0,1) + $LastName+ "-ext"
    }
    else{
        $UserName = $FirstName.Substring(0,1) + $LastName
    }

    $GUI["txtUserName"].Text = $UserName
}

$GUI["btnGenerateUsername"].Add_Click($ButtonClick)


#Show GUI
$Rawform.ShowDialog()








