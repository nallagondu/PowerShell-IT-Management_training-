$start = get-date
$PowerShell1 = [PowerShell]::Create() 
$PowerShell1.AddScript({Start-Sleep -Seconds 5;'Done1'})
$Async1 = $PowerShell1.BeginInvoke() 

$PowerShell2 = [PowerShell]::Create() 
$PowerShell2.AddScript({Start-Sleep -Seconds 5;'Done2'})
$Async2 = $PowerShell2.BeginInvoke() 

Write-Host "I can keep doing stuff until I need results" -ForegroundColor Green
Write-Host "Start waiting for both to finish..." -ForegroundColor Green

$PowerShell1.EndInvoke($Async1)
$PowerShell2.EndInvoke($Async2)

$end = Get-Date
($end-$start).Milliseconds

$PowerShell1.Dispose()
$PowerShell2.Dispose() 
