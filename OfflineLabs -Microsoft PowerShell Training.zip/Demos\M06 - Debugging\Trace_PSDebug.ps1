#Using trace-command to see parameter binding info
Trace-Command -PSHost -Expression {Start-Process Notepad} -Name ParameterBinding

#Showing trace level 2
Set-PSDebug -Trace 2
Function Foo {
  Write-Host "Foo"
}

Foo
$Var = "Hello World"
