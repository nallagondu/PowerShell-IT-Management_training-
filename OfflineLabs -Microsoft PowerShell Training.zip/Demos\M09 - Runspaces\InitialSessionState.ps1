$InitialState = [InitialSessionState]::CreateDefault() 
$var = [System.Management.Automation.Runspaces.SessionStateVariableEntry]::new("Name","value","description")
$InitialState.Variables.Add($var)
$PowerShell = [powershell]::create($InitialState)

$PowerShell.addscript({$Name})
$PowerShell.invoke()

$powerShell.Dispose() 
