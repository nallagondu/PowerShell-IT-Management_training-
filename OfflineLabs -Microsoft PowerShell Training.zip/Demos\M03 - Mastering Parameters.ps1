#region Mandatory + HelpMessage Attribute
Function Test-Mandatory{
  Param (
   [parameter(
    Mandatory = $true,
    HelpMessage = 'Enter a username'
   )]$UserName)
  Write-Host $UserName
 }

Test-Mandatory

#endregion Mandatory + HelpMessage Attribute

#region Positional Attribute
#shows defauls
Function Test-Position
{
  Param (
    [parameter()]$P1,
    [parameter()]$P2
  )
  Write-Host P1: $P1
  Write-Host P2: $P2
}

Test-Position 1 2

#Specify P2, which routes to that as the first position and now p1 doesn't support it anymore
Function Test-Position
{
  Param (
    [parameter()]$P1,
    [parameter(Position=0)]$P2
  )
  Write-Host P1 $P1
  Write-Host P2 $P2
}
Test-Position 1 2 #fails
Test-Position 1
#endregion Positional Attribute

#region ParameterSetName Attribute
Function ParamSets {
  Param (
      [String[]]$IP,

      [Parameter(ParameterSetName = "Machine")]
      [String[]]$MachineName,

      [Parameter(ParameterSetName = "User")]
      [String[]]$UserName
    )

    Write-Host "Set: $($PSCmdlet.ParameterSetName)" -ForegroundColor Green
}

Get-Command ParamSets -Syntax
ParamSets -MachineName "test"
ParamSets -UserName "test"
#endregion ParameterSetName Attribute

#region ValueFromPipeline Attribute
Function Test
{
    param(
        [parameter(ValueFromPipeline)][String]$a,
        [parameter(ValueFromPipeline)][int]$b,
        [parameter(ValueFromPipeline)][double]$c
    )
    process
    {
        write-host $a -ForegroundColor Green
        write-host $b -ForegroundColor yellow
        write-host $c -ForegroundColor cyan
    }
}

1,2,3,4,5 | Test
"a","b","c" | Test

Function Test-ValueFromPipline
{
 param([Parameter(ValueFromPipeline)]
       [int]$num)
 process
 {
  Write-Host $num -ForegroundColor Green
 }
}

1,2,"3" | Test-ValueFromPipline
"Fails" | Test-ValueFromPipline

#endregion ValueFromPipeline Attribute

#region ValueFromPipelineByPropertyName + Alias Attribute
Function Test-PipelineProperty{
  param(
    [parameter(ValueFromPipelineByPropertyName)]$Name,
    [parameter(ValueFromPipelineByPropertyName)]$Status,
    [parameter(ValueFromPipelineByPropertyName)]$StartType
  )
  Process{ Write-Host "$Name is $Status and $StartType" -ForegroundColor Green }
}

Get-service x* | Test-PipelineProperty

Function Test-PipelinePropertyWithAlias
{
    param(
        [parameter(ValueFromPipelineByPropertyName)][Alias("FirstName")]$First,
        [parameter(ValueFromPipelineByPropertyName)][Alias("LastName")]$Last,
        [parameter(ValueFromPipelineByPropertyName)][Alias("EmailAddress")]$Email
    )
    Process
    {
        Write-Host "$First $Last $Email" -ForegroundColor Green
    }
}

#needs a CSV with FirstName, LastName, and EmailAddress OR First, Last, Email or any combination to show alias working
Import-Csv .\People.csv | Test-PipelinePropertyWithAlias


#endregion ValueFromPipelineByPropertyName + Alias Attribute

#region RemainingArguments Attribute
#fails
Function Test-RemainingArguments {
  Param(
   [Parameter(Mandatory = $true)]$GivenName,
   [Parameter(Mandatory = $true)]$Surname
  )
  "GivenName: $GivenName"
  "Surname: $Surname"
}

Test-RemainingArguments John Doe Jr #fails

Function Test-RemainingArguments {
  Param(
   [Parameter(Mandatory = $true)]$GivenName,
   [Parameter(Mandatory = $true, ValueFromRemainingArguments = $true)]$Surname
  )
  "GivenName: $GivenName"
  "Surname: $Surname"
}

Test-RemainingArguments John Doe Jr
#endregion RemainingArguments Attribute

#region Validation
Function Write-Hello {
  Param (
    [ValidateSet("Morning","Afternoon","Evening")]$TimeOfDay
    )
    "Good $TimeOfDay"
}

#Show the intellisense completion
#Show it working
Write-Hello -TimeOfDay "Morning"
#Show it failing
Write-Hello -TimeOfDay "FAKE"

Function Test-Range{
  param([ValidateRange(2,5)]$num)
  Write-Host $num -ForegroundColor Green
}

Test-Range 3
#fails
Test-Range 6

Function Test-Pattern {
  param([ValidatePattern("\w{2}\d{4}")]$UserName)
  Write-Host $UserName -ForegroundColor Green
}

Test-Pattern JD1875
#fails
Test-Pattern John5

Function Test-ValidateScript
{
    Param ([ValidateScript({$_ -ge (get-date)})][DateTime]$EventDate)
    Write-Host "The event is set for $date" -ForegroundColor Green
}
$Tomorrow = (Get-Date).AddDays(1)
$Yesterday = $date.AddDays(-1)
Test-ValidateScript $Tomorrow
#fails
Test-ValidateScript $Yesterday
#endregion Validation

